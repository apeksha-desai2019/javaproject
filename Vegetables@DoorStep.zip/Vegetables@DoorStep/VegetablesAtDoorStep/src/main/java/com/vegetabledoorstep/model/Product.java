
package com.vegetabledoorstep.model;


import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "productTable")
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO )
	private long productId;
	
	@Column(name = "productName")
	private String productName;
	
	@Column(name = "productCategary")
	private String productCategary;
	
	@Column(name = "productDescription")
	private String productDescription;
	
	@Column(name = "price")
	private String price;
	
	@Column(name = "producturl")
	private String producturl;
	
	public Product() {
		
	}

	public Product(long productId, String productName, String productCategary,String productDescription, String price, String producturl) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategary = productCategary;
		this.productDescription = productDescription;
		this.price = price;
		this.producturl = producturl;
	}

	public String getProductCategary() {
		return productCategary;
	}

	public void setProductCategary(String productCategary) {
		this.productCategary = productCategary;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}


	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getProducturl() {
		return producturl;
	}

	public void setProducturl(String producturl) {
		this.producturl = producturl;
	}
	
	
	
	
}