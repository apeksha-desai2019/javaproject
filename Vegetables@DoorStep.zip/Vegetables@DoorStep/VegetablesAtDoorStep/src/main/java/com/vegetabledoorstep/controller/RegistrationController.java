package com.vegetabledoorstep.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vegetabledoorstep.model.User;
import com.vegetabledoorstep.service.RegistrationService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/vegetablesatdoorstep")
public class RegistrationController {
	
	@Autowired
	private RegistrationService service;
	
	
	@PostMapping("/register")
	public User registerUser(@RequestBody User user ) throws Exception
	{
		 String tempEmailId = user.getEmailId();
		 if (tempEmailId != null &&  !"".equals(tempEmailId) ) {
			User userobj = service.fetchUserByEmailId(tempEmailId);
			if(userobj != null) {
				throw new Exception("user with this id already exist!!!");
			}
			 
		 }
		 User userObj = null;
		 userObj = service.saveUser(user);
		 return  userObj;
	}
	
	@PostMapping("/login")
	public User loginUser(@RequestBody User user) throws Exception {
		String tempEmailId = user.getEmailId();
		String tempPass = user.getPassword();
		User userobj = null;
		if(tempEmailId !=null && tempPass !=null ) {
		userobj = service.fetchUserByEmailIdAndPassword(tempEmailId, tempPass);
		}
		
		if(userobj == null) {
			throw new Exception("bad credential");
			
		}
		return userobj;
	}

}