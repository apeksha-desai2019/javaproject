package com.vegetabledoorstep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VegetablesAtDoorStepApplication {

	public static void main(String[] args) {
		SpringApplication.run(VegetablesAtDoorStepApplication.class, args);
	}

}
